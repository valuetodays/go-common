##

打包
mvn clean package

// mvn exec:java

运行（*-fat.jar在target目录下）
java -jar simple-http-server-fat.jar

curl http://localhost:18080
