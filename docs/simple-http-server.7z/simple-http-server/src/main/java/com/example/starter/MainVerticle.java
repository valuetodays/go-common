package com.example.starter;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.buffer.impl.BufferImpl;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;

public class MainVerticle extends AbstractVerticle {

  @Override
  public void start(Promise<Void> startPromise) throws Exception {
    int port = 18080;
    vertx.createHttpServer().requestHandler(req -> {
      JsonObject jsonObject = new JsonObject();
      jsonObject.put("timestampMs", System.currentTimeMillis());
      jsonObject.put("poweredBy", "vert.x");
      jsonObject.put("intValue", System.currentTimeMillis() / 1000000);
//      new JsonObject()
      req.response()
        .putHeader("content-type", "application/json")
        .end(Json.encode(R.success(jsonObject).toJsonObject()));
    }).listen(port, http -> {
      if (http.succeeded()) {
        startPromise.complete();
        System.out.println("HTTP server started on port " + port);
      } else {
        startPromise.fail(http.cause());
      }
    });
  }
}
