package com.example.starter;

import io.vertx.core.json.JsonObject;

public class R<T> {
    private int code;
    private String msg;
    private T data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public static <T> R<T> success(T data) {
        R<T> t = new R<T>();
        t.setCode(200);
        t.setData(data);
        return t;
    }

    public JsonObject toJsonObject() {
        return JsonObject.of("code", code, "msg", msg, "data", data);
    }
}